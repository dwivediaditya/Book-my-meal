package com.bookmymeal.dao;

import com.bookmymeal.model.Admin;
import com.bookmymeal.service.GetConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDAO {
    public static boolean authenticateAdmin(Admin admin)
				{
					  boolean status = false;
							Connection con = null;
							try{
								con = GetConnection.getConnction();
								String sql = "select * from admin where username = ? and password = ?";
								PreparedStatement ps = con.prepareStatement(sql);
								ps.setString(1, admin.getUsername());
								ps.setString(2, admin.getPassword());
								ResultSet rs = ps.executeQuery();
								if(rs.next())
									status = true;
							}
							catch(Exception e)
							{
							  e.printStackTrace();
							}
							finally{
								 try{
										  con.close();
									}
									catch(Exception e)
									{
									  e.printStackTrace();
									}
							}
							return status;
				}												
}

