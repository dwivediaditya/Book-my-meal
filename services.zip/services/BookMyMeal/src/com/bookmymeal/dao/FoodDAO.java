package com.bookmymeal.dao;

import com.bookmymeal.model.Food;
import com.bookmymeal.service.GetConnectio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class FoodDAO {
	public static boolean updateFood(Food food){
		 boolean status = false;
			Connection con = null;
			try{
				con = GetConnectio.getConnection();
				String sql = "update food set name = ?,price=?,description=?,food_image=?,food_category_id=? where id = ?";
			 PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, food.getName());
				ps.setInt(2, food.getPrice());
				ps.setString(3, food.getDescription());
			 ps.setString(4, food.getFood_image());
				ps.setInt(5, food.getCategory_id());
				ps.setInt(6, food.getId());
				if(ps.executeUpdate()!=0)
					status = true;
			}
			catch(Exception e){
				  e.printStackTrace();
 		}
			finally{
				try{
					con.close();
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
			}
			return status;
	}
	public static Food getFoodItemById(Food food){
		 Connection con = null;
			Food f = null;
			try{
				con = GetConnectio.getConnection();
				String sql = "select *,food_category.category from food inner join food_category on food.food_category_id = food_category.id where food.id = ?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setInt(1, food.getId());
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
				  	String name = rs.getString(2);
							int price = rs.getInt(3);
							String desc = rs.getString(4);
							String foodImage = rs.getString(5);
							int categoryId = rs.getInt(6);
							String categoryName = rs.getString(8);	
							
							f = new Food();
							f.setId(food.getId());
							f.setName(name);
							f.setPrice(price);
							f.setDescription(desc);
							f.setFood_image(foodImage);
							f.setCategory_id(categoryId);
							f.setCagteoryName(categoryName);
				}
			}
			catch(Exception e)
			{
			  e.printStackTrace();
			}
			finally{
				 try{
						con.close();
					}
					catch(Exception e)
					{
					  e.printStackTrace();
					}
			}
			return f;
	}
	 public static boolean removeFood(Food food){
			 boolean status = false;
				Connection con = null;
				try{
					con  =GetConnectio.getConnection();
					String sql = "delete from food where id = ?";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setInt(1, food.getId());
					if(ps.executeUpdate()!=0)
						status =true;
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
				finally{
					 try{
							con.close();
						}
						catch(Exception e)
						{
						  e.printStackTrace();
						}
				}
				return status;
		}
  public static boolean saveFood(Food food)
		{
		  boolean status = false;
			 Connection con = null;
				try{
					con = GetConnectio.getConnection();
					String sql = "insert into food(name,price,description,food_image,food_category_id) values(?,?,?,?,?)";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1, food.getName());
					ps.setInt(2, food.getPrice());
					ps.setString(3, food.getDescription());
					ps.setString(4, food.getFood_image());
					ps.setInt(5, food.getCategory_id());
				 if(ps.executeUpdate()!=0)
						status = true;
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
				finally{
					 try{
							con.close();
						}
						catch(Exception e)
						{
						  e.printStackTrace();
						}
				}
				return status;
		}
		
		public static ArrayList<Food> getAllFoodList(){
			 Connection con = null;
				ArrayList<Food>al = new ArrayList<>();
				try{
					con  = GetConnectio.getConnection();
					String sql = "select *,food_category.category from food inner join food_category on food.food_category_id = food_category.id";
				 PreparedStatement ps = con.prepareStatement(sql);
					ResultSet rs = ps.executeQuery();
					while(rs.next()){
						 int id = rs.getInt(1);
							String name = rs.getString(2);
							int price = rs.getInt(3);
							String desc = rs.getString(4);
							String foodImage = rs.getString(5);
							int category_id = rs.getInt(6);
							String categoryName = rs.getString(8);
							
							Food food = new Food(id, name, price, desc, foodImage, category_id);
					  food.setCagteoryName(categoryName);
							al.add(food);
					}
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
				finally{
					 try{
							con.close();
						}
						catch(Exception e)
						{
						  e.printStackTrace();
						}
				}
				return al;
		}
}
