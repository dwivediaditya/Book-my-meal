package com.bookmymeal.dao;

import com.bookmymeal.service.GetConnectio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import com.bookmymeal.model.Package;
import java.sql.ResultSet;
import java.util.ArrayList;
public class PackageDAO {
	
	 public static ArrayList<Package> getPackageList(){
			ArrayList<Package>al = new ArrayList<>();
			Connection con = null;
			try{
				con = GetConnectio.getConnection();
				String sql = "select * from package";
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
					 int id  = rs.getInt(1);
						String name = rs.getString(2);
						String desc = rs.getString(3);
						int price = rs.getInt(4);
						String image = rs.getString(5);
						
						Package p = new Package(id, name, price, desc, image);
						al.add(p);
				}
			}
			catch(Exception e)
			{
			  e.printStackTrace();
			}
			finally{
				try{
					con.close();
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
			}
			return al;
		}
	
  public static boolean savePackage(Package p)
		{
		  boolean status = false;
				Connection con = null;
				try{
					con = GetConnectio.getConnection();
					String sql = "insert into package(package_name,package_desc,price,package_image) values(?,?,?,?)";
			  PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1, p.getName());
					ps.setString(2,p.getDescription());
					ps.setInt(3, p.getPrice());
					ps.setString(4, p.getPackage_image());
					if(ps.executeUpdate()!=0)
						status = true;
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
				finally{
					try{
						con.close();
					}
					catch(Exception e)
					{
					  e.printStackTrace();
					}
				}
				return status;
		}
}
