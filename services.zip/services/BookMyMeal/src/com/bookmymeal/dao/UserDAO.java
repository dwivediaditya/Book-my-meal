package com.bookmymeal.dao;

import com.bookmymeal.model.User;
import com.bookmymeal.service.DbConnection;
import com.bookmymeal.service.GetConnectio;
import com.bookmymeal.service.SendMailSSL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletContext;

public class UserDAO {
  public static boolean registerUser(User user,ServletContext context)
		{
			 boolean status = false;
		  Connection con = null;
				try{
					con = DbConnection.dbConnection(context);
					String sql = "insert into user(name,email,password,mobile) values(?,?,?,?)";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1,user.getUsername());
					ps.setString(2, user.getEmail());
					ps.setString(3, user.getPassword());
					ps.setString(4, user.getMobile());
					if(ps.executeUpdate()!=0){
								status = true;
					   //SendMailSSL.sendEmail(user.getEmail());
					}
			}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
				finally{
					try{
						con.close();
					}
					catch(Exception e)
					{
					  e.printStackTrace();
					}
				}
				return status;
		}
}
