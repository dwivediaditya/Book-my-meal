package com.bookmymeal.dao;

import com.bookmymeal.model.FoodCategory;
import com.bookmymeal.service.GetConnectio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class FoodCategoryDAO {
  public static boolean addCategory(FoodCategory foodCategory)
		{
			 boolean status = false;
				Connection con = null;
				try{
					con = GetConnectio.getConnection();
					String sql = "insert into food_category(category) values(?)";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1, foodCategory.getCategoryName());
					if(ps.executeUpdate()!=0)
						status = true;
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
				finally{
					 try{
							con.close();
						}
						catch(Exception e)
						{
						  e.printStackTrace();
						}
				}
				return status;
		}
		public static ArrayList<FoodCategory> getFoodCategoryList(){
			Connection con = null;
			ArrayList<FoodCategory>al = new ArrayList<>();
			try{
				con = GetConnectio.getConnection();
				String sql = "select * from food_category";
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
				  int id = rs.getInt(1);
						String categoryName = rs.getString(2);
				  FoodCategory fc = new FoodCategory(id, categoryName);
				  al.add(fc);
				}
			}
			catch(Exception e)
			{
			  e.printStackTrace();
			}
			finally{
				 try{
						con.close();
					}
					catch(Exception e)
					{
					  e.printStackTrace();
					}
			}
			return al;
		}
		
		public static boolean removeFoodCategory(FoodCategory foodCategory)
		{
		  boolean status = false;
				Connection con = null;
				try{
					con  =GetConnectio.getConnection();
					String sql = "delete from food_category where id = ?";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setInt(1, foodCategory.getId());
					if(ps.executeUpdate()!=0)
						status = true;
				}
				catch(Exception e)
				{
				  e.printStackTrace();
				}
				finally{
					 try{
							con.close();
						}
						catch(Exception e)
						{
						  e.printStackTrace();
						}
				}
				return status;
		}
}
