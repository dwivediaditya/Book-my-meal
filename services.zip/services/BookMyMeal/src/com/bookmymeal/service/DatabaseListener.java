package com.bookmymeal.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class DatabaseListener implements ServletContextListener{

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		 Connection con = null;
			try{
			  con = GetConnectio.getConnection();
					String sql = "create table admin(id int primary key auto_increment,username varchar(100),password varchar(100))";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.execute();
					con.close();
			}
			catch(Exception e)
			{
			
			}
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
   		
	}
  	
}
