package com.bookmymeal.service;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.ServletContext;

public class DbConnection {
	  private static Connection con = null;
			public static Connection dbConnection(ServletContext context)
			{
				 try{
						  String username = context.getInitParameter("username");
								String password = context.getInitParameter("password");
					   String dbUrl = context.getInitParameter("dbUrl");
								String driver = context.getInitParameter("driver");
								Class.forName(driver);
								con = DriverManager.getConnection(dbUrl, username,password);
					}
					catch(Exception e)
					{
					
					}
			  return con;
			}
}
