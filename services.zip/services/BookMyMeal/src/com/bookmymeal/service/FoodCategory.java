package com.bookmymeal.service;

public class FoodCategory {
   private int id;
			private String category_name;

	public FoodCategory(int id, String category_name) {
		this.id = id;
		this.category_name = category_name;
	}
			
}
