package com.bookmymeal.service;
public class Food {
  private int id;
		private String name;
		private int price;
		private String description;
		private int categoryId;
		private String categoryName;
		private String image;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
		

	public Food(int id, String name, int price, String description, int categoryId, String categoryName) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.description = description;
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

	public Food(int id, String name, int price, String description, int categoryId) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.description = description;
		this.categoryId = categoryId;
	}

	public Food() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
		
}
