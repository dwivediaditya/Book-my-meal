package com.bookmymeal.controller;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterFilter implements Filter{

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		 boolean status = true;
		 HttpServletRequest request = (HttpServletRequest)req;
			HttpServletResponse response = (HttpServletResponse)res;
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String mobile = request.getParameter("mobile");
			String email = request.getParameter("email");
			
			username = username.trim();
			if(username.length() == 0)
			{
			    request.setAttribute("usernameError", "Please enter username");
			    status = false;
			}
			if(password.length() == 0)
			{
			  request.setAttribute("passwordError", "Please enter password");
			  status = false;
			}
			if(email.length() == 0)
			{
			  request.setAttribute("emailError", "Please enter email");
			  status = false;
			}
			if(mobile.length() == 0)
			{
			  request.setAttribute("mobileError","Please enter mobile");
			  status = false;
			}
		 if(status)
			{
			  chain.doFilter(request, response);
			}
			else
			{
			   RequestDispatcher rd = request.getRequestDispatcher("registration.jsp");
      rd.forward(request, response);
      
			}
	}

	@Override
	public void destroy() {
		
	}
	 
}
